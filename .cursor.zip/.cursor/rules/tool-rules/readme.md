Rules specific to different tools, such as git, linux commands, direction of usage of MCP tools.
