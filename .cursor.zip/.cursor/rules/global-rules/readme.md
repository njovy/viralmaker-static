All globally applying always on rules that will bloat every chat and cmd-k context go here.

Rules in this folder will have alwaysApply: true with blank descriptions and globs.

These are equivalent to the root project .cursorrules files (which are now deprecated and may be removed in a future cursor version)
