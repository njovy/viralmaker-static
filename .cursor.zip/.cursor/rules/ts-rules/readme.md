TypeScript Specific Rules belong in this folder
