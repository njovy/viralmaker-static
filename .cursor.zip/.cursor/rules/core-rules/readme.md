Core rules related to cursor or rule generation
