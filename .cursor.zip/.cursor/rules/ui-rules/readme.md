Any rules related to react, html, css, angular, frontend development, etc... belong in this folder.
